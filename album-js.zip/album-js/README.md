# Album JS

A Pen created on CodePen.

Original URL: [https://codepen.io/OSCAR-ACOSTAGUINEA/pen/empoaYj](https://codepen.io/OSCAR-ACOSTAGUINEA/pen/empoaYj).

