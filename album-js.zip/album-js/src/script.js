//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [

  "https://images.pexels.com/photos/7504630/pexels-photo-7504630.jpeg",
  "https://images.pexels.com/photos/7504630/pexels-photo-7504630.jpeg",
  "https://images.pexels.com/photos/2886042/pexels-photo-2886042.jpeg",
  "https://images.pexels.com/photos/9404825/pexels-photo-9404825.jpeg",
  "https://images.pexels.com/photos/33024125/pexels-photo-33024125.jpeg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});