# JS-colors change

A Pen created on CodePen.

Original URL: [https://codepen.io/OSCAR-ACOSTAGUINEA/pen/VYvgQLP](https://codepen.io/OSCAR-ACOSTAGUINEA/pen/VYvgQLP).

